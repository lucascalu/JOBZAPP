import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            'Política Privacidade',
            style: GoogleFonts.spectral(textStyle: TextStyle(color: Colors.white)),
          ),
          backgroundColor: Colors.red[900],
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [
                  Colors.red[800],
                  Colors.red[900],
                  Colors.brown[900],
                  Colors.black
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                stops: [
                  0.1,
                  0.3,
                  0.5,
                  0.9
                ]),
          ),
          child: Column(
            children: [
              Text(
                "Política Privacidade",
                style: TextStyle(height: 5, fontSize: 30, color: Colors.white),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                child: Text(
                  "A sua privacidade é importante para nós. É política do JOBZ respeitar a sua privacidade em relação a qualquer informação sua que possamos coletar no app JOBZ, e outros apps que possuímos e operamos.",
                  style: TextStyle(height: 1, fontSize: 20, color: Colors.white),
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                child: Text(
                  "Solicitamos informações pessoais apenas quando realmente precisamos delas para lhe fornecer um serviço. Fazemo-lo por meios justos e legais, com o seu conhecimento e consentimento. Também informamos por que estamos coletando e como será usado.",
                  style: TextStyle(height: 1, fontSize: 20, color: Colors.white),
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                child: Text(
                  "Apenas retemos as informações coletadas pelo tempo necessário para fornecer o serviço solicitado. Quando armazenamos dados, protegemos dentro de meios comercialmente aceitáveis ​​para evitar perdas e roubos, bem como acesso, divulgação, cópia, uso ou modificação não autorizados.",
                  style: TextStyle(height: 1, fontSize: 20, color: Colors.white),
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                child: Text(
                  "Não compartilhamos informações de identificação pessoal publicamente ou com terceiros, exceto quando exigido por lei.",
                  style: TextStyle(height: 1, fontSize: 20, color: Colors.white),
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                child: Text(
                  "O nosso app pode ter links para sites externos que não são operados por nós. Esteja ciente de que não temos controle sobre o conteúdo e práticas desses sites e não podemos aceitar responsabilidade por suas respectivas políticas de privacidade.",
                  style: TextStyle(height: 1, fontSize: 20, color: Colors.white),
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                child: Text(
                  "Você é livre para recusar a nossa solicitação de informações pessoais, entendendo que talvez não possamos fornecer alguns dos serviços desejados.",
                  style: TextStyle(height: 1, fontSize: 20, color: Colors.white),
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                child: Text(
                  "O uso continuado de nosso app será considerado como aceitação de nossas práticas em torno de privacidade e informações pessoais. Se você tiver alguma dúvida sobre como lidamos com dados do usuário e informações pessoais, entre em contacto connosco.",
                  style: TextStyle(height: 1, fontSize: 20, color: Colors.white),
                ),
              ),
              TextButton(
                onPressed: () => Get.toNamed('/http'),
                child: Text(
                  'OK',
                  style: GoogleFonts.spectral(
                    textStyle: TextStyle(color: Colors.white),
                    fontSize: 20,
                  ),
                ),
              ),
            ],
          ),
        )));
  }
}
