package br.com.academiadoflutter.consumindo_api_com_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
