import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

class CdjobPage extends StatefulWidget {
  @override
  _CdjobPageState createState() => _CdjobPageState();
}

class _CdjobPageState extends State<CdjobPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Cadastrar Jobz',
          style: GoogleFonts.spectral(textStyle: TextStyle(color: Colors.white)),
        ),
        backgroundColor: Colors.red[900],
        centerTitle: true,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Icon(
            Icons.email_outlined,
            size: 300,
          ),
          Text(
            'QUER OFERTAR TRABALHO NA JOBZ?',
            textAlign: TextAlign.center,
            style: GoogleFonts.spectral(textStyle: TextStyle(fontSize: 25)),
          ),
          Text(
            'LIGUE AGORA PARA JOBZ OU ENVIE UM EMAIL',
            textAlign: TextAlign.center,
            style: GoogleFonts.spectral(textStyle: TextStyle(fontSize: 25)),
          ),
          TextButton(
            onPressed: () => Get.toNamed('/http'),
            child: Text(
              'OK',
              style: TextStyle(fontSize: 30, color: Colors.red[900]),
            ),
          ),
//
        ],
      ),
    );
  }
}
