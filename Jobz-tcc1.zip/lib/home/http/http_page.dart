import 'package:consumindo_api_com_flutter/home/http/http_controller.dart';
import 'package:consumindo_api_com_flutter/model/user_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

//

class HttpPage extends GetView<HttpController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Exibir Jobz',
          style: GoogleFonts.spectral(textStyle: TextStyle(color: Colors.white)),
        ),
        backgroundColor: Colors.red[900],
        centerTitle: true,
      ),

      backgroundColor: Colors.red[900],
      drawer: Drawer(
          child: ListView(
        children: <Widget>[
          ListTile(
              leading: Icon(Icons.star),
              title: Text("Login", style: GoogleFonts.spectral(fontSize: 20, textStyle: TextStyle(color: Colors.black))),
              subtitle: Text("fazer login...", style: GoogleFonts.spectral(textStyle: TextStyle(color: Colors.black))),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {
                Get.toNamed('/login');
              }),

//
          ListTile(
              leading: Icon(Icons.star),
              title: Text("Cadastrar Job", style: GoogleFonts.spectral(fontSize: 20, textStyle: TextStyle(color: Colors.black))),
              subtitle: Text("ofereça trabalho...", style: GoogleFonts.spectral(textStyle: TextStyle(color: Colors.black))),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {
                Get.toNamed('/cdjob');
              })

//
        ],
      )),
      //

      body: controller.obx((state) {
        return ListView.builder(
          padding: EdgeInsets.all(10.0),
          itemCount: state.length,
          itemBuilder: (_, index) {
            final UserModel item = state[index];
            return ListTile(
              leading: CircleAvatar(
                backgroundImage: NetworkImage(item.photo), //vai sair o imageUrl e colocar item.o nome do negocio que vamos puxar nojson)
              ),
              title: Text(item.name, style: GoogleFonts.spectral(fontSize: 20, textStyle: TextStyle(color: Colors.white))),
              subtitle: Text(item.contact, style: GoogleFonts.spectral(fontSize: 20, textStyle: TextStyle(color: Colors.white))),
              //types.length
              //
              //

              //
              //
            );
          },
        );

        //

        //
      }, onError: (error) {
        return SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(error),
              TextButton(
                onPressed: () => controller.findUsers(),
                child: Text('Tentar novamente'),
              )
            ],
          ),
        );
      }),
    );
  }

  Widget _jobCard(BuildContext context, int index, String name, String photo, String contact) {
    return GestureDetector(
      child: Card(
        color: Colors.white12,
        child: Padding(
          padding: EdgeInsets.all(10.0),
          child: Row(
            children: [
              Container(
                width: 80.0,
                height: 80.0,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                      image: AssetImage('assets/images/person.png'),
                    )),
              ),
              Padding(
                padding: EdgeInsets.only(left: 10.0),
                child: Column(
                  children: [
                    Text(name, style: GoogleFonts.spectral(fontSize: 30, textStyle: TextStyle(color: Colors.white), fontWeight: FontWeight.bold)),
                    Text(contact, style: GoogleFonts.spectral(fontSize: 20, textStyle: TextStyle(color: Colors.white))),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
