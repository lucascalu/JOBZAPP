import 'dart:async';
import 'dart:ui';
import 'package:consumindo_api_com_flutter/home/home_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:google_fonts/google_fonts.dart';

bool a = false;

class SplashPage extends StatefulWidget {
  @override
  _SplashPageState createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    startTimer();
  }

  startTimer() async {
    var duration = Duration(seconds: 4);
    return Timer(duration, route);
  }

//

//

  route() {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomePage()));
  }
  //

  //

//

//
//

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.red[800],
              Colors.red[900],
              Colors.black
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Stack(
          children: [
            Center(
              child: Text('j', style: GoogleFonts.spectral(fontSize: 250, textStyle: TextStyle(color: Colors.black26))),
            ),
            Center(
              child: Text('jobz', style: GoogleFonts.spectral(fontSize: 80, textStyle: TextStyle(color: Colors.white))),
            ),
          ],
        ),
      ),
    );
  }
}
